

function calValorFerroM(peso,hora1,data){

            let cobre = 0.5*peso;
            console.log("TOTAL: " + cobre);
            let preco = '0,50$ por KG';
            let nomeFerroM = 'Ferro Maneiro';
            
            let tb = document.getElementById("tbAreaTrabalho");
                var qtdlinhas = tb.rows.lenght;
                var linha = tb.insertRow(qtdlinhas);
            
                var cellnomeFerroM =  linha.insertCell(0);
                var cellpeso = linha.insertCell(1)
                var cellpreco = linha.insertCell(2);
                var cellhora1 = linha.insertCell(3);
                var celldata = linha.insertCell(4)
                var cellcobre = linha.insertCell(5);
              
                celldata.innerHTML = data;
                cellhora1.innerHTML = hora1;
                cellpeso.innerHTML = peso + ' kg';
                cellcobre.innerHTML = cobre.toFixed(2) + "$";
                cellpreco.innerHTML = preco;
                cellnomeFerroM.innerHTML = nomeFerroM;
        
            } 
function calValorFerroP(peso,hora1,data){

                let cobre = 0.7*peso;
                console.log("TOTAL: " + cobre);
                let preco = '0,70$ por KG';
                let nomeFerroP = 'Ferro Pesado';
                
                let tb = document.getElementById("tbAreaTrabalho");
                    var qtdlinhas = tb.rows.lenght;
                    var linha = tb.insertRow(qtdlinhas);
                
                    var cellnomeFerroP =  linha.insertCell(0);
                    var cellpeso = linha.insertCell(1)
                    var cellpreco = linha.insertCell(2);
                    var cellhora1 = linha.insertCell(3);
                    var celldata = linha.insertCell(4)
                    var cellcobre = linha.insertCell(5);
                  
                    celldata.innerHTML = data;
                    cellhora1.innerHTML = hora1;
                    cellpeso.innerHTML = peso + ' kg';
                    cellcobre.innerHTML = cobre.toFixed(2) + "$";
                    cellpreco.innerHTML = preco;;
                    cellnomeFerroP.innerHTML = nomeFerroP;
            
                }
function calValorMetal(peso,hora1,data){

                    let metal = 15*peso;
                    console.log("TOTAL: " + metal);
                    let preco = '15,00$ por KG';
                    let nomeMetal = 'Metal';
                    
                    let tb = document.getElementById("tbAreaTrabalho");
                        var qtdlinhas = tb.rows.lenght;
                        var linha = tb.insertRow(qtdlinhas);
                    
                        var cellnomeMetal =  linha.insertCell(0);
                        var cellpeso = linha.insertCell(1)
                        var cellpreco = linha.insertCell(2);
                        var cellhora1 = linha.insertCell(3);
                        var celldata = linha.insertCell(4)
                        var cellmetal = linha.insertCell(5);
                      
                        celldata.innerHTML = data;
                        cellhora1.innerHTML = hora1;
                        cellpeso.innerHTML = peso + ' kg';
                        cellmetal.innerHTML = metal.toFixed(2) + "$";
                        cellpreco.innerHTML = preco;;
                        cellnomeMetal.innerHTML = nomeMetal;
                
                    }
function calValorPanela(peso,hora1,data){

                        let metal = 7*peso;
                        console.log("TOTAL: " + metal);
                        let preco = '7,00$ por KG';
                        let nomePanela = 'Panela';
                        
                        let tb = document.getElementById("tbAreaTrabalho");
                            var qtdlinhas = tb.rows.lenght;
                            var linha = tb.insertRow(qtdlinhas);
                        
                            var cellnomePanela =  linha.insertCell(0);
                            var cellpeso = linha.insertCell(1)
                            var cellpreco = linha.insertCell(2);
                            var cellhora1 = linha.insertCell(3);
                            var celldata = linha.insertCell(4)
                            var cellmetal = linha.insertCell(5);
                          
                            celldata.innerHTML = data;
                            cellhora1.innerHTML = hora1;
                            cellpeso.innerHTML = peso + ' kg';
                            cellmetal.innerHTML = metal.toFixed(2) + "$";
                            cellpreco.innerHTML = preco;;
                            cellnomePanela.innerHTML = nomePanela;
                    
                        }                                                                                          
function calValorDuroL(peso,hora1,data){

                            let metal = 3*peso;
                            console.log("TOTAL: " + metal);
                            let preco = '3,00$ por KG';
                            let nomeDuroL = 'Duro limpo';
                            
                            let tb = document.getElementById("tbAreaTrabalho");
                                var qtdlinhas = tb.rows.lenght;
                                var linha = tb.insertRow(qtdlinhas);
                            
                                var cellnomeDuroL =  linha.insertCell(0);
                                var cellpeso = linha.insertCell(1)
                                var cellpreco = linha.insertCell(2);
                                var cellhora1 = linha.insertCell(3);
                                var celldata = linha.insertCell(4)
                                var cellmetal = linha.insertCell(5);
                              
                                celldata.innerHTML = data;
                                cellhora1.innerHTML = hora1;
                                cellpeso.innerHTML = peso + ' kg';
                                cellmetal.innerHTML = metal.toFixed(2) + "$";
                                cellpreco.innerHTML = preco;;
                                cellnomeDuroL.innerHTML = nomeDuroL;
                        
                            }
function calValorDuroS(peso,hora1,data){

                                let metal = 1.5*peso;
                                console.log("TOTAL: " + metal);
                                let preco = '1,50$ por KG';
                                let nomeDuroS = 'Duro Sujo';
                                
                                let tb = document.getElementById("tbAreaTrabalho");
                                    var qtdlinhas = tb.rows.lenght;
                                    var linha = tb.insertRow(qtdlinhas);
                                
                                    var cellnomeDuroS =  linha.insertCell(0);
                                    var cellpeso = linha.insertCell(1)
                                    var cellpreco = linha.insertCell(2);
                                    var cellhora1 = linha.insertCell(3);
                                    var celldata = linha.insertCell(4)
                                    var cellmetal = linha.insertCell(5);
                                  
                                    celldata.innerHTML = data;
                                    cellhora1.innerHTML = hora1;
                                    cellpeso.innerHTML = peso + ' kg';
                                    cellmetal.innerHTML = metal.toFixed(2) + "$";
                                    cellpreco.innerHTML = preco;;
                                    cellnomeDuroS.innerHTML = nomeDuroS;
                            
                                }                            
function calValorChapa(peso,hora1,data){

                                let metal = 3*peso;
                                console.log("TOTAL: " + metal);
                                let preco = '4,00$ por KG';
                                let nomeChapa = 'Chaparia';
                                
                                let tb = document.getElementById("tbAreaTrabalho");
                                    var qtdlinhas = tb.rows.lenght;
                                    var linha = tb.insertRow(qtdlinhas);
                                
                                    var cellnomeChapa =  linha.insertCell(0);
                                    var cellpeso = linha.insertCell(1)
                                    var cellpreco = linha.insertCell(2);
                                    var cellhora1 = linha.insertCell(3);
                                    var celldata = linha.insertCell(4)
                                    var cellmetal = linha.insertCell(5);
                                  
                                    celldata.innerHTML = data;
                                    cellhora1.innerHTML = hora1;
                                    cellpeso.innerHTML = peso + ' kg';
                                    cellmetal.innerHTML = metal.toFixed(2) + "$";
                                    cellpreco.innerHTML = preco;;
                                    cellnomeChapa.innerHTML = nomeChapa;
                            
                                }
function calValorPitu(peso,hora1,data){

                                    let metal = 0.7*peso;
                                    console.log("TOTAL: " + metal);
                                    let preco = '0,70$ por KG';
                                    let nomePitu = 'Pitú';
                                    
                                    let tb = document.getElementById("tbAreaTrabalho");
                                        var qtdlinhas = tb.rows.lenght;
                                        var linha = tb.insertRow(qtdlinhas);
                                    
                                        var cellnomePitu =  linha.insertCell(0);
                                        var cellpeso = linha.insertCell(1)
                                        var cellpreco = linha.insertCell(2);
                                        var cellhora1 = linha.insertCell(3);
                                        var celldata = linha.insertCell(4)
                                        var cellmetal = linha.insertCell(5);
                                      
                                        celldata.innerHTML = data;
                                        cellhora1.innerHTML = hora1;
                                        cellpeso.innerHTML = peso + ' kg';
                                        cellmetal.innerHTML = metal.toFixed(2) + "$";
                                        cellpreco.innerHTML = preco;;
                                        cellnomePitu.innerHTML = nomePitu;
                                
                                    } 
function calValorChumbo(peso,hora1,data){

                                        let metal = 4*peso;
                                        console.log("TOTAL: " + metal);
                                        let preco = '4,00$ por KG';
                                        let nomeChumbo = 'CHUMBO';
                                        
                                        let tb = document.getElementById("tbAreaTrabalho");
                                            var qtdlinhas = tb.rows.lenght;
                                            var linha = tb.insertRow(qtdlinhas);
                                        
                                            var cellnomeChumbo =  linha.insertCell(0);
                                            var cellpeso = linha.insertCell(1)
                                            var cellpreco = linha.insertCell(2);
                                            var cellhora1 = linha.insertCell(3);
                                            var celldata = linha.insertCell(4)
                                            var cellmetal = linha.insertCell(5);
                                          
                                            celldata.innerHTML = data;
                                            cellhora1.innerHTML = hora1;
                                            cellpeso.innerHTML = peso + ' kg';
                                            cellmetal.innerHTML = metal.toFixed(2) + "$";
                                            cellpreco.innerHTML = preco;;
                                            cellnomeChumbo.innerHTML = nomeChumbo;
                                    
                                        }      
function calValorInox(peso,hora1,data){

                                            let metal = 1*peso;
                                            console.log("TOTAL: " + metal);
                                            let preco = '1,00$ por KG';
                                            let nomeInox = 'Inox';
                                            
                                            let tb = document.getElementById("tbAreaTrabalho");
                                                var qtdlinhas = tb.rows.lenght;
                                                var linha = tb.insertRow(qtdlinhas);
                                            
                                                var cellnomeInox =  linha.insertCell(0);
                                                var cellpeso = linha.insertCell(1)
                                                var cellpreco = linha.insertCell(2);
                                                var cellhora1 = linha.insertCell(3);
                                                var celldata = linha.insertCell(4)
                                                var cellmetal = linha.insertCell(5);
                                              
                                                celldata.innerHTML = data;
                                                cellhora1.innerHTML = hora1;
                                                cellpeso.innerHTML = peso + ' kg';
                                                cellmetal.innerHTML = metal.toFixed(2) + "$";
                                                cellpreco.innerHTML = preco;;
                                                cellnomeInox.innerHTML = nomeInox;
                                        
                                            }                                                                                     
                                                                           
    
