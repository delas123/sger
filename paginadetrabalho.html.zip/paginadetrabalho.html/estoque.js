const myCobre = {total: parseFloat(localStorage.getItem('totalCobre')) || 0};
const myMel = {total: parseFloat(localStorage.getItem('totalMel')) || 0};
const myPlastico = {total: parseFloat(localStorage.getItem('totalPlastico')) || 0};
const myFilme = {total: parseFloat(localStorage.getItem('totalFilme')) || 0};
const myFerroM = {total: parseFloat(localStorage.getItem('totalFerroM')) || 0};
const myFerroP = {total: parseFloat(localStorage.getItem('totalFerroP')) || 0};
const myChaparia = {total: parseFloat(localStorage.getItem('totalChaparia')) || 0};
const myPanela = {total: parseFloat(localStorage.getItem('totalPanela')) || 0};
const myDuroL = {total: parseFloat(localStorage.getItem('totalDuroL')) || 0};
const myDuroS = {total: parseFloat(localStorage.getItem('totalDuroS')) || 0};
const myMetal = {total: parseFloat(localStorage.getItem('totalMetal')) || 0};
const myPitu = {total: parseFloat(localStorage.getItem('totalPitu')) || 0};
const myInox = {total: parseFloat(localStorage.getItem('totalInox')) || 0};
const myChumbo = {total: parseFloat(localStorage.getItem('totalChumbo')) || 0};
const myLata = {total: parseFloat(localStorage.getItem('totalLata')) || 0};

function calValorCobre(peso, hora1, data, Cliente) {
    let cobre = 30 * peso;
    let preco = '30,00$ por KG';
    let nomeCobre = 'Cobre';
    const valor = parseFloat(peso.replace(',', '.'));
    if (!isNaN(valor)) {
        const multiplicacao = valor * 30;
        myCobre.total += multiplicacao;
        localStorage.setItem('totalCobre', myCobre.total.toFixed(2));
        let newRow = {
            nome: nomeCobre,
            peso: peso + ' kg',
            preco: preco,
            hora: hora1,
            data: data,
            valor: cobre.toFixed(2) + "$",
            cliente: Cliente
        };
        addTableRow(newRow);
        saveTableRows();
        updatePesoCobre();
    } else {
        alert("Por favor, insira um número válido.");
    }
}
function calValorMel(peso, hora1, data, Cliente) {
    let mel = 33 * peso;
    let preco = '33,00$ por KG';
    let nomeMel = 'Mel';
    const valor = parseFloat(peso.replace(',', '.'));
    if (!isNaN(valor)) {
        const multiplicacao = valor * 33;
        myMel.total += multiplicacao;
        localStorage.setItem('totalMel', myMel.total.toFixed(2));
        let newRow = {
            nome: nomeMel,
            peso: peso + ' kg',
            preco: preco,
            hora: hora1,
            data: data,
            valor: mel.toFixed(2) + "$",
            cliente: Cliente
        };
        addTableRow(newRow);
        saveTableRows();
        updatePesoMel();
    } else {
        alert("Por favor, insira um número válido.");
    }
}
function calValorPlastico(peso, hora1, data, Cliente) {
    let Plastico = 0.8 * peso;
    let preco = '0.80$ por KG';
    let nomePlastico = 'Plástico';
    const valor = parseFloat(peso.replace(',', '.'));
    if (!isNaN(valor)) {
        const multiplicacao = valor * 0.8;
        myPlastico.total += multiplicacao;
        localStorage.setItem('totalPlastico', myPlastico.total.toFixed(2));
        let newRow = {
            nome: nomePlastico,
            peso: peso + ' kg',
            preco: preco,
            hora: hora1,
            data: data,
            valor: Plastico.toFixed(2) + "$",
            cliente: Cliente
        };
        addTableRow(newRow);
        saveTableRows();
        updatePesoPlastico();
    } else {
        alert("Por favor, insira um número válido.");
    }
}
function calValorFerroM(peso, hora1, data, Cliente) {
    let FerroM = 0.6 * peso;
    let preco = '0,60$ por KG';
    let nomeFerroM = 'Ferro Maneiro';
    const valor = parseFloat(peso.replace(',', '.'));
    if (!isNaN(valor)) {
        const multiplicacao = valor * 0.6;
        myFerroM.total += multiplicacao;
        localStorage.setItem('totalFerroM', myFerroM.total.toFixed(2));
        let newRow = {
            nome: nomeFerroM,
            peso: peso + ' kg',
            preco: preco,
            hora: hora1,
            data: data,
            valor: FerroM.toFixed(2) + "$",
            cliente: Cliente
        };
        addTableRow(newRow);
        saveTableRows();
        updatePesoFerroM();
    } else {
        alert("Por favor, insira um número válido.");
    }
}
function calValorFilme(peso, hora1, data, Cliente) {
    let Filme = 0.5 * peso;
    let preco = '0,50$ por KG';
    let nomeFilme = 'Filme';
    const valor = parseFloat(peso.replace(',', '.'));
    if (!isNaN(valor)) {
        const multiplicacao = valor * 0.5;
        myFilme.total += multiplicacao;
        localStorage.setItem('totalFilme', myFilme.total.toFixed(2));
        let newRow = {
            nome: nomeFilme,
            peso: peso + ' kg',
            preco: preco,
            hora: hora1,
            data: data,
            valor: Filme.toFixed(2) + "$",
            cliente: Cliente
        };
        addTableRow(newRow);
        saveTableRows();
        updatePesoFilme();
    } else {
        alert("Por favor, insira um número válido.");
    }
}
function calValorFerroP(peso, hora1, data, Cliente) {
    let FerroP = 0.7 * peso;
    let preco = '0,70$ por KG';
    let nomeFerroP = 'Ferro Pesado';
    const valor = parseFloat(peso.replace(',', '.'));
    if (!isNaN(valor)) {
        const multiplicacao = valor * 0.7;
        myFerroP.total += multiplicacao;
        localStorage.setItem('totalFerroP', myFerroP.total.toFixed(2));
        let newRow = {
            nome: nomeFerroP,
            peso: peso + ' kg',
            preco: preco,
            hora: hora1,
            data: data,
            valor: FerroP.toFixed(2) + "$",
            cliente: Cliente
        };
        addTableRow(newRow);
        saveTableRows();
        updatePesoFerroP();
    } else {
        alert("Por favor, insira um número válido.");
    }
}
function calValorChaparia(peso, hora1, data, Cliente) {
    let Chaparia = 4 * peso;
    let preco = '4,00$ por KG';
    let nomeChaparia = 'Chaparia';
    const valor = parseFloat(peso.replace(',', '.'));
    if (!isNaN(valor)) {
        const multiplicacao = valor * 4;
        myChaparia.total += multiplicacao;
        localStorage.setItem('totalChaparia', myChaparia.total.toFixed(2));
        let newRow = {
            nome: nomeChaparia,
            peso: peso + ' kg',
            preco: preco,
            hora: hora1,
            data: data,
            valor: Chaparia.toFixed(2) + "$",
            cliente: Cliente
        };
        addTableRow(newRow);
        saveTableRows();
        updatePesoChaparia();
    } else {
        alert("Por favor, insira um número válido.");
    }
}
function calValorPanela(peso, hora1, data, Cliente) {
    let Panela = 7 * peso;
    let preco = '7,00$ por KG';
    let nomePanela = 'Panela';
    const valor = parseFloat(peso.replace(',', '.'));
    if (!isNaN(valor)) {
        const multiplicacao = valor * 7;
        myPanela.total += multiplicacao;
        localStorage.setItem('totalPanela', myPanela.total.toFixed(2));
        let newRow = {
            nome: nomePanela,
            peso: peso + ' kg',
            preco: preco,
            hora: hora1,
            data: data,
            valor: Panela.toFixed(2) + "$",
            cliente: Cliente
        };
        addTableRow(newRow);
        saveTableRows();
        updatePesoPanela();
    } else {
        alert("Por favor, insira um número válido.");
    }
}
function calValorDuroL(peso, hora1, data, Cliente) {
    let DuroL = 3 * peso;
    let preco = '3,00$ por KG';
    let nomeDuroL = 'Duro Limpo';
    const valor = parseFloat(peso.replace(',', '.'));
    if (!isNaN(valor)) {
        const multiplicacao = valor * 3;
        myDuroL.total += multiplicacao;
        localStorage.setItem('totalDuroL', myDuroL.total.toFixed(2));
        let newRow = {
            nome: nomeDuroL,
            peso: peso + ' kg',
            preco: preco,
            hora: hora1,
            data: data,
            valor: DuroL.toFixed(2) + "$",
            cliente: Cliente
        };
        addTableRow(newRow);
        saveTableRows();
        updatePesoDuroL();
    } else {
        alert("Por favor, insira um número válido.");
    }
}
function calValorDuroS(peso, hora1, data, Cliente) {
    let DuroS = 1.5 * peso;
    let preco = '1,50$ por KG';
    let nomeDuroS = 'Duro Sujo';
    const valor = parseFloat(peso.replace(',', '.'));
    if (!isNaN(valor)) {
        const multiplicacao = valor * 1.5;
        myDuroS.total += multiplicacao;
        localStorage.setItem('totalDuroS', myDuroS.total.toFixed(2));
        let newRow = {
            nome: nomeDuroS,
            peso: peso + ' kg',
            preco: preco,
            hora: hora1,
            data: data,
            valor: DuroS.toFixed(2) + "$",
            cliente: Cliente
        };
        addTableRow(newRow);
        saveTableRows();
        updatePesoDuroS();
    } else {
        alert("Por favor, insira um número válido.");
    }
}
function calValorMetal(peso, hora1, data, Cliente) {
    let Metal = 15 * peso;
    let preco = '15,00$ por KG';
    let nomeMetal = 'Metal';
    const valor = parseFloat(peso.replace(',', '.'));
    if (!isNaN(valor)) {
        const multiplicacao = valor * 15;
        myMetal.total += multiplicacao;
        localStorage.setItem('totalMetal', myMetal.total.toFixed(2));
        let newRow = {
            nome: nomeMetal,
            peso: peso + ' kg',
            preco: preco,
            hora: hora1,
            data: data,
            valor: Metal.toFixed(2) + "$",
            cliente: Cliente
        };
        addTableRow(newRow);
        saveTableRows();
        updatePesoMetal();
    } else {
        alert("Por favor, insira um número válido.");
    }
}
function calValorPitu(peso, hora1, data, Cliente) {
    let Pitu = 0.7 * peso;
    let preco = '0,70$ por KG';
    let nomePitu = 'Pitú';
    const valor = parseFloat(peso.replace(',', '.'));
    if (!isNaN(valor)) {
        const multiplicacao = valor * 0.7;
        myPitu.total += multiplicacao;
        localStorage.setItem('totalPitu', myPitu.total.toFixed(2));
        let newRow = {
            nome: nomePitu,
            peso: peso + ' kg',
            preco: preco,
            hora: hora1,
            data: data,
            valor: Pitu.toFixed(2) + "$",
            cliente: Cliente
        };
        addTableRow(newRow);
        saveTableRows();
        updatePesoPitu();
    } else {
        alert("Por favor, insira um número válido.");
    }
}
function calValorInox(peso, hora1, data, Cliente) {
    let Inox = 1 * peso;
    let preco = '1,00$ por KG';
    let nomeInox = 'Inox';
    const valor = parseFloat(peso.replace(',', '.'));
    if (!isNaN(valor)) {
        const multiplicacao = valor * 1;
        myInox.total += multiplicacao;
        localStorage.setItem('totalInox', myInox.total.toFixed(2));
        let newRow = {
            nome: nomeInox,
            peso: peso + ' kg',
            preco: preco,
            hora: hora1,
            data: data,
            valor: Inox.toFixed(2) + "$",
            cliente: Cliente
        };
        addTableRow(newRow);
        saveTableRows();
        updatePesoInox();
    } else {
        alert("Por favor, insira um número válido.");
    }
}
function calValorChumbo(peso, hora1, data, Cliente) {
    let Chumbo = 4 * peso;
    let preco = '4,00$ por KG';
    let nomeChumbo = 'Chumbo';
    const valor = parseFloat(peso.replace(',', '.'));
    if (!isNaN(valor)) {
        const multiplicacao = valor * 4;
        myChumbo.total += multiplicacao;
        localStorage.setItem('totalChumbo', myChumbo.total.toFixed(2));
        let newRow = {
            nome: nomeChumbo,
            peso: peso + ' kg',
            preco: preco,
            hora: hora1,
            data: data,
            valor: Chumbo.toFixed(2) + "$",
            cliente: Cliente
        };
        addTableRow(newRow);
        saveTableRows();
        updatePesoChumbo();
    } else {
        alert("Por favor, insira um número válido.");
    }
}
function calValorLata(peso, hora1, data, Cliente) {
    let Lata = 6 * peso;
    let preco = '6,00$ por KG';
    let nomeLata = 'Lata';
    const valor = parseFloat(peso.replace(',', '.'));
    if (!isNaN(valor)) {
        const multiplicacao = valor * 6;
        myLata.total += multiplicacao;
        localStorage.setItem('totalLata', myLata.total.toFixed(2));
        let newRow = {
            nome: nomeLata,
            peso: peso + ' kg',
            preco: preco,
            hora: hora1,
            data: data,
            valor: Lata.toFixed(2) + "$",
            cliente: Cliente
        };
        addTableRow(newRow);
        saveTableRows();
        updatePesoLata();
    } else {
        alert("Por favor, insira um número válido.");
    }
}
function addTableRow(rowData) {
    let tb = document.getElementById("tbAreaTrabalho");
    let linha = tb.insertRow(1);

    linha.insertCell(0).innerText = rowData.nome;
    linha.insertCell(1).innerText = rowData.peso;
    linha.insertCell(2).innerText = rowData.preco;
    linha.insertCell(3).innerText = rowData.hora;
    linha.insertCell(4).innerText = rowData.data;
    linha.insertCell(5).innerText = rowData.valor;
    linha.insertCell(6).innerText = rowData.cliente;

    let cellExcluir = linha.insertCell(7);
    let btnExcluir = document.createElement("button");
    btnExcluir.innerText = "Excluir";
    btnExcluir.onclick = function() {
        removeTableRow(btnExcluir);
    };
    cellExcluir.appendChild(btnExcluir);
}
function limparTabela() {
    let tb = document.getElementById("tbAreaTrabalho");
    if (confirm("Tem certeza que quer limpar tudo?")) {
        while (tb.rows.length > 1) {
            tb.deleteRow(1);
        }
        saveTableRows();
    }
}
function removeTableRow(button) {
    let row = button.parentNode.parentNode;
    row.parentNode.removeChild(row);
    saveTableRows();
}
let style = document.createElement('style');
style.innerHTML = `
    .btnExcluir {
        width: 54px;
        height: 20px;
    }
`;
document.head.appendChild(style);
function saveTableRows() {
    let tb = document.getElementById("tbAreaTrabalho");
    let rows = [];
    for (let i = 1; i < tb.rows.length; i++) {
        let cells = tb.rows[i].cells;
        rows.push({
            nome: cells[0].innerText,
            peso: cells[1].innerText,
            preco: cells[2].innerText,
            hora: cells[3].innerText,
            data: cells[4].innerText,
            valor: cells[5].innerText,
            cliente: cells[6].innerText
        });
    }
    localStorage.setItem('tableRows', JSON.stringify(rows));
}
function loadTableRows() {
    let rows = JSON.parse(localStorage.getItem('tableRows') || '[]');
    for (let row of rows) {
        addTableRow(row);
    }
}
function atualizarElementoCobre() {
    let vendido = parseFloat(prompt("Quantos kg de cobre foram vendidos?").replace(',', '.'));
    if (isNaN(vendido) || vendido <= 0) {
        alert("Por favor, insira um número válido.");
        return;
    }
    let pesoCobreElem = document.getElementById("pesoCobre");
    let pesoAtual = parseFloat(pesoCobreElem.innerText.split(' ')[0].replace(',', '.'));
    if (pesoAtual < vendido) {
        alert("A quantidade vendida é maior que o peso disponível.");
        return;
    }
    let novoPeso = pesoAtual - vendido;
    pesoCobreElem.innerText = novoPeso.toFixed(2) + " kg";
    myCobre.total -= vendido * 30;
    localStorage.setItem('totalCobre', myCobre.total.toFixed(2));
    updateTables();
}
function atualizarElementoMel() {
    let vendido = parseFloat(prompt("Quantos kg de Cobre mel foram vendidos?").replace(',', '.'));
    if (isNaN(vendido) || vendido <= 0) {
        alert("Por favor, insira um número válido.");
        return;
    }
    let pesoMelElem = document.getElementById("pesoMel");
    let pesoAtual = parseFloat(pesoMelElem.innerText.split(' ')[0].replace(',', '.'));
    if (pesoAtual < vendido) {
        alert("A quantidade vendida é maior que o peso disponível.");
        return;
    }
    let novoPeso = pesoAtual - vendido;
    pesoMelElem.innerText = novoPeso.toFixed(2) + " kg";
    myMel.total -= vendido * 33;
    localStorage.setItem('totalMel', myMel.total.toFixed(2));
    updateTables();
}
function atualizarElementoPlastico() {
    let vendido = parseFloat(prompt("Quantos kg de Plastico foram vendidos?").replace(',', '.'));
    if (isNaN(vendido) || vendido <= 0) {
        alert("Por favor, insira um número válido.");
        return;
    }
    let pesoPlasticoElem = document.getElementById("pesoPlastico");
    let pesoAtual = parseFloat(pesoPlasticoElem.innerText.split(' ')[0].replace(',', '.'));
    if (pesoAtual < vendido) {
        alert("A quantidade vendida é maior que o peso disponível.");
        return;
    }
    let novoPeso = pesoAtual - vendido;
    pesoPlasticoElem.innerText = novoPeso.toFixed(2) + " kg";
    myPlastico.total -= vendido * 0.8;
    localStorage.setItem('totalPlastico', myPlastico.total.toFixed(2));
    updateTables();
}
function atualizarElementoFilme() {
    let vendido = parseFloat(prompt("Quantos kg de Filme foram vendidos?").replace(',', '.'));

    if (isNaN(vendido) || vendido <= 0) {
        alert("Por favor, insira um número válido.");
        return;
    }
    let pesoFilmeElem = document.getElementById("pesoFilme");
    let pesoAtual = parseFloat(pesoFilmeElem.innerText.split(' ')[0].replace(',', '.'));

    if (pesoAtual < vendido) {
        alert("A quantidade vendida é maior que o peso disponível.");
        return;
    }
    let novoPeso = pesoAtual - vendido;
    pesoFilmeElem.innerText = novoPeso.toFixed(2) + " kg";
    myFilme.total -= vendido * 0.5;
    localStorage.setItem('totalFilme', myFilme.total.toFixed(2));
    updateTables();
}
function atualizarElementoFerroM() {
    let vendido = parseFloat(prompt("Quantos kg de Ferro Maneiro foram vendidos?").replace(',', '.'));
    if (isNaN(vendido) || vendido <= 0) {
        alert("Por favor, insira um número válido.");
        return;
    }
    let pesoFerroMElem = document.getElementById("pesoFerroM");
    let pesoAtual = parseFloat(pesoFerroMElem.innerText.split(' ')[0].replace(',', '.'));
    if (pesoAtual < vendido) {
        alert("A quantidade vendida é maior que o peso disponível.");
        return;
    }
    let novoPeso = pesoAtual - vendido;
    pesoFerroMElem.innerText = novoPeso.toFixed(2) + " kg";
    myFerroM.total -= vendido * 0.6;
    localStorage.setItem('totalFerroM', myFerroM.total.toFixed(2));
    updateTables();
}
function atualizarElementoFerroP() {
    let vendido = parseFloat(prompt("Quantos kg de Ferro Pesado foram vendidos?").replace(',', '.'));
    if (isNaN(vendido) || vendido <= 0) {
        alert("Por favor, insira um número válido.");
        return;
    }
    let pesoFerroPElem = document.getElementById("pesoFerroP");
    let pesoAtual = parseFloat(pesoFerroPElem.innerText.split(' ')[0].replace(',', '.'));

    if (pesoAtual < vendido) {
        alert("A quantidade vendida é maior que o peso disponível.");
        return;
    }
    let novoPeso = pesoAtual - vendido;
    pesoFerroPElem.innerText = novoPeso.toFixed(2) + " kg";

    myFerroP.total -= vendido * 0.7;
    localStorage.setItem('totalFerroP', myFerroP.total.toFixed(2));
    updateTables();
}
function atualizarElementoChaparia() {
    let vendido = parseFloat(prompt("Quantos kg de Chaparia foram vendidos?").replace(',', '.'));
    if (isNaN(vendido) || vendido <= 0) {
        alert("Por favor, insira um número válido.");
        return;
    }
    let pesoChapariaElem = document.getElementById("pesoChaparia");
    let pesoAtual = parseFloat(pesoChapariaElem.innerText.split(' ')[0].replace(',', '.'));
    if (pesoAtual < vendido) {
        alert("A quantidade vendida é maior que o peso disponível.");
        return;
    }
    let novoPeso = pesoAtual - vendido;
    pesoChapariaElem.innerText = novoPeso.toFixed(2) + " kg";

    myChaparia.total -= vendido * 4;
    localStorage.setItem('totalChaparia', myChaparia.total.toFixed(2));
    updateTables();
}
function atualizarElementoPanela() {
    let vendido = parseFloat(prompt("Quantos kg de Panela foram vendidos?").replace(',', '.'));
    if (isNaN(vendido) || vendido <= 0) {
        alert("Por favor, insira um número válido.");
        return;
    }
    let pesoPanelaElem = document.getElementById("pesoPanela");
    let pesoAtual = parseFloat(pesoPanelaElem.innerText.split(' ')[0].replace(',', '.'));
    if (pesoAtual < vendido) {
        alert("A quantidade vendida é maior que o peso disponível.");
        return;
    }
    let novoPeso = pesoAtual - vendido;
    pesoPanelaElem.innerText = novoPeso.toFixed(2) + " kg";

    myPanela.total -= vendido * 7;
    localStorage.setItem('totalPanela', myPanela.total.toFixed(2));
    updateTables();
}
function atualizarElementoDuroL() {
    let vendido = parseFloat(prompt("Quantos kg de Duro Limpo foram vendidos?").replace(',', '.'));
    if (isNaN(vendido) || vendido <= 0) {
        alert("Por favor, insira um número válido.");
        return;
    }
    let pesoDuroLElem = document.getElementById("pesoDuroL");
    let pesoAtual = parseFloat(pesoDuroLElem.innerText.split(' ')[0].replace(',', '.'));
    if (pesoAtual < vendido) {
        alert("A quantidade vendida é maior que o peso disponível.");
        return;
    }
    let novoPeso = pesoAtual - vendido;
    pesoDuroLElem.innerText = novoPeso.toFixed(2) + " kg";

    myDuroL.total -= vendido * 3;
    localStorage.setItem('totalDuroL', myDuroL.total.toFixed(2));
    updateTables();
}
function atualizarElementoDuroS() {
    let vendido = parseFloat(prompt("Quantos kg de Duro Sujo foram vendidos?").replace(',', '.'));
    if (isNaN(vendido) || vendido <= 0) {
        alert("Por favor, insira um número válido.");
        return;
    }
    let pesoDuroSElem = document.getElementById("pesoDuroS");
    let pesoAtual = parseFloat(pesoDuroSElem.innerText.split(' ')[0].replace(',', '.'));
    if (pesoAtual < vendido) {
        alert("A quantidade vendida é maior que o peso disponível.");
        return;
    }
    let novoPeso = pesoAtual - vendido;
    pesoDuroSElem.innerText = novoPeso.toFixed(2) + " kg";

    myDuroS.total -= vendido * 1.5;
    localStorage.setItem('totalDuroS', myDuroS.total.toFixed(2));
    updateTables();
}
function atualizarElementoMetal() {
    let vendido = parseFloat(prompt("Quantos kg de Metal foram vendidos?").replace(',', '.'));
    if (isNaN(vendido) || vendido <= 0) {
        alert("Por favor, insira um número válido.");
        return;
    }
    let pesoMetalElem = document.getElementById("pesoMetal");
    let pesoAtual = parseFloat(pesoMetalElem.innerText.split(' ')[0].replace(',', '.'));
    if (pesoAtual < vendido) {
        alert("A quantidade vendida é maior que o peso disponível.");
        return;
    }
    let novoPeso = pesoAtual - vendido;
    pesoMetalElem.innerText = novoPeso.toFixed(2) + " kg";

    myMetal.total -= vendido * 15;
    localStorage.setItem('totalMetal', myMetal.total.toFixed(2));
    updateTables();
}
function atualizarElementoPitu() {
    let vendido = parseFloat(prompt("Quantos Litros de Pitú foram vendidos?").replace(',', '.'));
    if (isNaN(vendido) || vendido <= 0) {
        alert("Por favor, insira um número válido.");
        return;
    }
    let pesoPituElem = document.getElementById("pesoPitu");
    let pesoAtual = parseFloat(pesoPituElem.innerText.split(' ')[0].replace(',', '.'));
    if (pesoAtual < vendido) {
        alert("A quantidade vendida é maior que o peso disponível.");
        return;
    }
    let novoPeso = pesoAtual - vendido;
    pesoPituElem.innerText = novoPeso.toFixed(2) + " kg";

    myPitu.total -= vendido * 0.7;
    localStorage.setItem('totalPitu', myPitu.total.toFixed(2));
    updateTables();
}
function atualizarElementoInox() {
    let vendido = parseFloat(prompt("Quantos kg de inox foram vendidos?").replace(',', '.'));
    if (isNaN(vendido) || vendido <= 0) {
        alert("Por favor, insira um número válido.");
        return;
    }
    let pesoInoxElem = document.getElementById("pesoInox");
    let pesoAtual = parseFloat(pesoInoxElem.innerText.split(' ')[0].replace(',', '.'));
    if (pesoAtual < vendido) {
        alert("A quantidade vendida é maior que o peso disponível.");
        return;
    }
    let novoPeso = pesoAtual - vendido;
    pesoInoxElem.innerText = novoPeso.toFixed(2) + " kg";

    myInox.total -= vendido * 1;
    localStorage.setItem('totalInox', myInox.total.toFixed(2));
    updateTables();
}
function atualizarElementoChumbo() {
    let vendido = parseFloat(prompt("Quantos kg de Chumbo foram vendidos?").replace(',', '.'));
    if (isNaN(vendido) || vendido <= 0) {
        alert("Por favor, insira um número válido.");
        return;
    }
    let pesoChumboElem = document.getElementById("pesoChumbo");
    let pesoAtual = parseFloat(pesoChumboElem.innerText.split(' ')[0].replace(',', '.'));
    if (pesoAtual < vendido) {
        alert("A quantidade vendida é maior que o peso disponível.");
        return;
    }
    let novoPeso = pesoAtual - vendido;
    pesoChumboElem.innerText = novoPeso.toFixed(2) + " kg";

    myChumbo.total -= vendido * 4;
    localStorage.setItem('totalChumbo', myChumbo.total.toFixed(2));
    updateTables();
}
function atualizarElementoLata() {
    let vendido = parseFloat(prompt("Quantos Kg de Lata foram vendidos?").replace(',', '.'));
    if (isNaN(vendido) || vendido <= 0) {
        alert("Por favor, insira um número válido.");
        return;
    }
    let pesoLataElem = document.getElementById("pesoLata");
    let pesoAtual = parseFloat(pesoLataElem.innerText.split(' ')[0].replace(',', '.'));
    if (pesoAtual < vendido) {
        alert("A quantidade vendida é maior que o peso disponível.");
        return;
    }
    let novoPeso = pesoAtual - vendido;
    pesoLataElem.innerText = novoPeso.toFixed(2) + " kg";

    myLata.total -= vendido * 6;
    localStorage.setItem('totalLata', myLata.total.toFixed(2));
    updateTables();
}
function updatePesoCobre() {
    let totalCobre = parseFloat(localStorage.getItem('totalCobre')) || 0;
    let precoPorKgCobre = 30; 
    let pesoCobre = totalCobre / precoPorKgCobre;
    let elem = document.getElementById("pesoCobre");

    if (elem) {
        elem.innerHTML = pesoCobre.toFixed(2) + " kg";
    }
}
function updatePesoMel() {
    let totalMel = parseFloat(localStorage.getItem('totalMel')) || 0;
    let precoPorKgMel = 33;
    let pesoMel = totalMel / precoPorKgMel;
    let elem = document.getElementById("pesoMel");

    if (elem) {
        elem.innerHTML = pesoMel.toFixed(2) + " kg";
    }
}
function updatePesoPlastico() {
    let totalPlastico = parseFloat(localStorage.getItem('totalPlastico')) || 0;
    let precoPorKgPlastico = 0.8;
    let pesoPlastico = totalPlastico / precoPorKgPlastico;
    let elem = document.getElementById("pesoPlastico");

    if (elem) {
        elem.innerHTML = pesoPlastico.toFixed(2) + " kg";
    }
}
function updatePesoFilme() {
    let totalFilme = parseFloat(localStorage.getItem('totalFilme')) || 0;
    let precoPorKgFilme = 0.5;
    let pesoFilme = totalFilme / precoPorKgFilme;
    let elem = document.getElementById("pesoFilme");

    if (elem) {
        elem.innerHTML = pesoFilme.toFixed(2) + " kg";
    }
}
function updatePesoFerroM() {
    let totalFerroM = parseFloat(localStorage.getItem('totalFerroM')) || 0;
    let precoPorKgFerroM = 0.6;
    let pesoFerroM = totalFerroM / precoPorKgFerroM;
    let elem = document.getElementById("pesoFerroM");

    if (elem) {
        elem.innerHTML = pesoFerroM.toFixed(2) + " kg";
    }
}
function updatePesoFerroP() {
    let totalFerroP = parseFloat(localStorage.getItem('totalFerroP')) || 0;
    let precoPorKgFerroP = 0.7;
    let pesoFerroP = totalFerroP / precoPorKgFerroP;
    let elem = document.getElementById("pesoFerroP");

    if (elem) {
        elem.innerHTML = pesoFerroP.toFixed(2) + " kg";
    }
}
function updatePesoChaparia() {
    let totalChaparia = parseFloat(localStorage.getItem('totalChaparia')) || 0;
    let precoPorKgChaparia = 4;
    let pesoChaparia = totalChaparia / precoPorKgChaparia;
    let elem = document.getElementById("pesoChaparia");

    if (elem) {
        elem.innerHTML = pesoChaparia.toFixed(2) + " kg";
    }
}
function updatePesoPanela() {
    let totalPanela = parseFloat(localStorage.getItem('totalPanela')) || 0;
    let precoPorKgPanela= 7;
    let pesoPanela = totalPanela / precoPorKgPanela;
    let elem = document.getElementById("pesoPanela");

    if (elem) {
        elem.innerHTML = pesoPanela.toFixed(2) + " kg";
    }
}
function updatePesoDuroL() {
    let totalDuroL = parseFloat(localStorage.getItem('totalDuroL')) || 0;
    let precoPorKgDuroL= 3;
    let pesoDuroL = totalDuroL / precoPorKgDuroL;
    let elem = document.getElementById("pesoDuroL");

    if (elem) {
        elem.innerHTML = pesoDuroL.toFixed(2) + " kg";
    }
}
function updatePesoDuroS() {
    let totalDuroS = parseFloat(localStorage.getItem('totalDuroS')) || 0;
    let precoPorKgDuroS= 1.5;
    let pesoDuroS = totalDuroS / precoPorKgDuroS;
    let elem = document.getElementById("pesoDuroS");

    if (elem) {
        elem.innerHTML = pesoDuroS.toFixed(2) + " kg";
    }
}
function updatePesoMetal() {
    let totalMetal = parseFloat(localStorage.getItem('totalMetal')) || 0;
    let precoPorKgMetal= 15;
    let pesoMetal = totalMetal / precoPorKgMetal;
    let elem = document.getElementById("pesoMetal");

    if (elem) {
        elem.innerHTML = pesoMetal.toFixed(2) + " kg";
    }
}
function updatePesoPitu() {
    let totalPitu = parseFloat(localStorage.getItem('totalPitu')) || 0;
    let precoPorKgPitu= 0.7;
    let pesoPitu= totalPitu / precoPorKgPitu;
    let elem = document.getElementById("pesoPitu");

    if (elem) {
        elem.innerHTML = pesoPitu.toFixed(2) + " kg";
    }
}
function updatePesoInox() {
    let totalInox = parseFloat(localStorage.getItem('totalInox')) || 0;
    let precoPorKgInox= 1;
    let pesoInox = totalInox / precoPorKgInox;
    let elem = document.getElementById("pesoInox");

    if (elem) {
        elem.innerHTML = pesoInox.toFixed(2) + " kg";}
}
function updatePesoChumbo() {
    let totalChumbo = parseFloat(localStorage.getItem('totalChumbo')) || 0;
    let precoPorKgChumbo= 4;
    let pesoChumbo = totalChumbo / precoPorKgChumbo;
    let elem = document.getElementById("pesoChumbo");

    if (elem) {
        elem.innerHTML = pesoChumbo.toFixed(2) + " kg";}
}
function updatePesoLata() {
    let totalLata = parseFloat(localStorage.getItem('totalLata')) || 0;
    let precoPorKgLata = 6;
    let pesoLata = totalLata / precoPorKgLata;
    let elem = document.getElementById("pesoLata");

    if (elem) {
        elem.innerHTML = pesoLata.toFixed(2) + " kg";}
}
function updateTables() {
    let totalCobre = localStorage.getItem('totalCobre');
    if (totalCobre !== null) {
        let elem = document.getElementById("totalCobre");
        if (elem) {
            elem.innerHTML = totalCobre + " $";
        }}
    updatePesoCobre();

    let totalMel = localStorage.getItem('totalMel');
    if (totalMel !== null) {
        let elem = document.getElementById("totalMel");
        if (elem) {
            elem.innerHTML = totalMel + " $";
        }}
    updatePesoMel();

    let totalPlastico = localStorage.getItem('totalPlastico');
    if (totalPlastico !== null) {
        let elem = document.getElementById("totalPlastico");
        if (elem) {
            elem.innerHTML = totalPlastico + " $";
        }}
    updatePesoPlastico();

    let totalFilme = localStorage.getItem('totalFilme');
    if (totalFilme !== null) {
        let elem = document.getElementById("totalFilme");
        if (elem) {
            elem.innerHTML = totalFilme + " $";
        }}
    updatePesoFilme();

    let totalFerroM = localStorage.getItem('totalFerroM');
    if (totalFerroM !== null) {
        let elem = document.getElementById("totalFerroM");
        if (elem) {
            elem.innerHTML = totalFerroM + " $";
        }}
    updatePesoFerroM();
    
    let totalFerroP = localStorage.getItem('totalFerroP');
    if (totalFerroP !== null) {
        let elem = document.getElementById("totalFerroP");
        if (elem) {
            elem.innerHTML = totalFerroP + " $";
        }}
    updatePesoFerroP();
     
    let totalChaparia = localStorage.getItem('totalChaparia');
    if (totalChaparia !== null) {
        let elem = document.getElementById("totalChaparia");
        if (elem) {
            elem.innerHTML = totalChaparia + " $";
        }}
    updatePesoChaparia();
     
    let totalPanela = localStorage.getItem('totalPanela');
    if (totalPanela !== null) {
        let elem = document.getElementById("totalPanela");
        if (elem) {
            elem.innerHTML = totalPanela + " $";
        }}
    updatePesoPanela();
     
    let totalDuroL = localStorage.getItem('totalDuroL');
    if (totalDuroL !== null) {
        let elem = document.getElementById("totalDuroL");
        if (elem) {
            elem.innerHTML = totalDuroL + " $";
        }}
    updatePesoDuroL();
     
    let totalDuroS = localStorage.getItem('totalDuroS');
    if (totalDuroS !== null) {
        let elem = document.getElementById("totalDuroS");
        if (elem) {
            elem.innerHTML = totalDuroS + " $";
        }}
    updatePesoDuroS();
     
    let totalMetal = localStorage.getItem('totalMetal');
    if (totalMetal !== null) {
        let elem = document.getElementById("totalMetal");
        if (elem) {
            elem.innerHTML = totalMetal + " $";
        }}
    updatePesoMetal();
     
    let totalPitu = localStorage.getItem('totalPitu');
    if (totalPitu !== null) {
        let elem = document.getElementById("totalPitu");
        if (elem) {
            elem.innerHTML = totalPitu + " $";
        }}
    updatePesoPitu();
     
    let totalInox = localStorage.getItem('totalInox');
    if (totalInox !== null) {
        let elem = document.getElementById("totalInox");
        if (elem) {
            elem.innerHTML = totalInox + " $";
        }}
    updatePesoInox();
     
    let totalChumbo = localStorage.getItem('totalChumbo');
    if (totalChumbo !== null) {
        let elem = document.getElementById("totalChumbo");
        if (elem) {
            elem.innerHTML = totalChumbo + " $";
        }}
    updatePesoChumbo();
     
    let totalLata = localStorage.getItem('totalLata');
    if (totalLata !== null) {
        let elem = document.getElementById("totalLata");
        if (elem) {
            elem.innerHTML = totalLata + " $";
        }}
    updatePesoLata();
    loadTableRows();
}
window.onload = updateTables;