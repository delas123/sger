document.addEventListener("DOMContentLoaded", function() {
    loadGastos();

    document.getElementById("fGastos").addEventListener("submit", function(event) {
        event.preventDefault();
        const data = this.txtdata.value;
        const descrição = this.txtdescrição.value;
        const categoria = this.txtcategoria.value;
        const valor = this.txtvalor.value;
        cadGastos(data, descrição, categoria, valor);
    });
});

function cadGastos(data, descrição, categoria, valor) {
    var tb = document.getElementById("tbGastos").getElementsByTagName('tbody')[0];
    var linha = tb.insertRow(-1);  

    var celldata = linha.insertCell(0);
    var celldescrição = linha.insertCell(1);
    var cellcategoria = linha.insertCell(2);
    var cellvalor = linha.insertCell(3);
    var cellDelete = linha.insertCell(4);

    celldata.innerHTML = data;
    celldescrição.innerHTML = descrição;
    cellcategoria.innerHTML = categoria;
    cellvalor.innerHTML = valor;
    cellDelete.innerHTML = `<button onclick="deleteGasto(this)">Excluir</button>`;

    saveGastos();
}

function saveGastos() {
    var tb = document.getElementById("tbGastos").getElementsByTagName('tbody')[0];
    var gastos = [];
    for (var i = 0; i < tb.rows.length; i++) {
        var row = tb.rows[i];
        var gasto = {
            data: row.cells[0].innerText,
            descrição: row.cells[1].innerText,
            categoria: row.cells[2].innerText,
            valor: row.cells[3].innerText
        };
        gastos.push(gasto);
    }
    localStorage.setItem("gastos", JSON.stringify(gastos));
}

function loadGastos() {
    var tb = document.getElementById("tbGastos").getElementsByTagName('tbody')[0];
    if (!tb) {
        console.error("Elemento tbody não encontrado");
        return;
    }
    var gastos = JSON.parse(localStorage.getItem("gastos")) || [];
    gastos.forEach(gasto => {
        var linha = tb.insertRow();
        

        var celldata = linha.insertCell(0);
        var celldescrição = linha.insertCell(1);
        var cellcategoria = linha.insertCell(2);
        var cellvalor = linha.insertCell(3);
        var cellDelete = linha.insertCell(4);

        celldata.innerHTML = gasto.data;
        celldescrição.innerHTML = gasto.descrição;
        cellcategoria.innerHTML = gasto.categoria;
        cellvalor.innerHTML = gasto.valor;
        cellDelete.innerHTML = `<button onclick="deleteGasto(this)">Excluir</button>`;
    });
}

function deleteGasto(button) {
    var row = button.parentNode.parentNode;
    row.parentNode.removeChild(row);
    saveGastos();
    alert("Gasto excluído com sucesso!");
}

document.addEventListener("DOMContentLoaded", function() {
    loadFuncionarios();

    document.getElementById("fFuncionarios").addEventListener("submit", function(event) {
        event.preventDefault();
        const nome = this.nome.value;
        const contato = this.contato.value;
        const endereço = this.endereço.value;
        const email = this.email.value;
        const datadeingresso = this.datadeingresso.value;
        cadFuncionarios(nome, contato, endereço, email, datadeingresso);
    });
});

function cadFuncionarios(nome, contato, endereço, email, datadeingresso) {
    var tb = document.getElementById("tbFuncionarios").getElementsByTagName('tbody')[0];
    var linha = tb.insertRow(-1);

    var cellnome = linha.insertCell(0);
    var cellcontato = linha.insertCell(1);
    var cellendereço = linha.insertCell(2);
    var cellemail = linha.insertCell(3);
    var celldatadeingresso = linha.insertCell(4);
    var cellExcluir = linha.insertCell(5);

    cellnome.innerHTML = nome;
    cellcontato.innerHTML = contato;
    cellendereço.innerHTML = endereço;
    cellemail.innerHTML = email;
    celldatadeingresso.innerHTML = datadeingresso;
    cellExcluir.innerHTML = `<button onclick="deleteFuncionarios(this)">Excluir</button>`;

    saveFuncionarios();
}

function saveFuncionarios() {
    var tb = document.getElementById("tbFuncionarios").getElementsByTagName('tbody')[0];
    var funcionarios = [];
    for (var i = 0; i < tb.rows.length; i++) {
        var row = tb.rows[i];
        var funcionario = {
            nome: row.cells[0].innerText,
            contato: row.cells[1].innerText,
            endereço: row.cells[2].innerText,
            email: row.cells[3].innerText,
            datadeingresso: row.cells[4].innerText
        };
        funcionarios.push(funcionario);
    }
    localStorage.setItem("funcionarios", JSON.stringify(funcionarios));
}

function loadFuncionarios() {
    var funcionarios = JSON.parse(localStorage.getItem("funcionarios")) || [];
    var tb = document.getElementById("tbFuncionarios").getElementsByTagName('tbody')[0];
    if (!tb) {
        console.error("Elemento tbody não encontrado");
        return;
    }
    for (var i = 0; i < funcionarios.length; i++) {
        var funcionario = funcionarios[i];
        var linha = tb.insertRow();

        var cellnome = linha.insertCell(0);
        var cellcontato = linha.insertCell(1);
        var cellendereço = linha.insertCell(2);
        var cellemail = linha.insertCell(3);
        var celldatadeingresso = linha.insertCell(4);
        var cellExcluir = linha.insertCell(5);

        cellnome.innerHTML = funcionario.nome;
        cellcontato.innerHTML = funcionario.contato;
        cellendereço.innerHTML = funcionario.endereço;
        cellemail.innerHTML = funcionario.email;
        celldatadeingresso.innerHTML = funcionario.datadeingresso;
        cellExcluir.innerHTML = `<button onclick="deleteFuncionarios(this)">Excluir</button>`;
    }
}

function updateFuncionarios() {
    var nome = prompt("Digite o nome do funcionário a ser atualizado:");
    var funcionarios = JSON.parse(localStorage.getItem("funcionarios")) || [];
    var tb = document.getElementById("tbFuncionarios").getElementsByTagName('tbody')[0];

    for (var i = 0; i < funcionarios.length; i++) {
        if (funcionarios[i].nome === nome) {
            funcionarios[i].contato = prompt("Atualize o contato:", funcionarios[i].contato);
            funcionarios[i].endereço = prompt("Atualize o endereço:", funcionarios[i].endereço);
            funcionarios[i].email = prompt("Atualize o email:", funcionarios[i].email);
            funcionarios[i].datadeingresso = prompt("Atualize a data de ingresso:", funcionarios[i].datadeingresso);

            // Atualiza os dados na linha da tabela
            for (var j = 0; j < tb.rows.length; j++) {
                if (tb.rows[j].cells[0].innerText === nome) {
                    tb.rows[j].cells[1].innerText = funcionarios[i].contato;
                    tb.rows[j].cells[2].innerText = funcionarios[i].endereço;
                    tb.rows[j].cells[3].innerText = funcionarios[i].email;
                    tb.rows[j].cells[4].innerText = funcionarios[i].datadeingresso;
                }
            }
            break;
        }
    }
    localStorage.setItem("funcionarios", JSON.stringify(funcionarios));
    alert("Funcionário atualizado com sucesso!");
}

function deleteFuncionarios(button) {
    var row = button.parentNode.parentNode;
    var nome = row.cells[0].innerText;
    if (confirm("Tem certeza que deseja excluir o funcionário " + nome + "?")) {
        var funcionarios = JSON.parse(localStorage.getItem("funcionarios")) || [];
        funcionarios = funcionarios.filter(function(funcionario) {
            return funcionario.nome !== nome;
        });
        localStorage.setItem("funcionarios", JSON.stringify(funcionarios));
        row.parentNode.removeChild(row); // Remove a linha da tabela
        alert("Funcionário excluído com sucesso!");
    }
}

document.addEventListener("DOMContentLoaded", function() {
    loadFolha();

    document.getElementById("fFolha").addEventListener("submit", function(event) {
        event.preventDefault();
        const nome = this.nome.value;
        const cpf = this.cpf.value;
        const data = this.data.value;
        const valor = this.valor.value;
        cadFolha(nome, cpf, data, valor);
    });
});

function cadFolha(nome, cpf, data, valor) {
    var tb = document.getElementById("tbFolha").getElementsByTagName('tbody')[0];
    var linha = tb.insertRow(-1);

    var cellNome = linha.insertCell(0);
    var cellCpf = linha.insertCell(1);
    var cellData = linha.insertCell(2);
    var cellValor = linha.insertCell(3);
    var cellExcluir = linha.insertCell(4);

    cellNome.innerHTML = nome;
    cellCpf.innerHTML = cpf;
    cellData.innerHTML = data;
    cellValor.innerHTML = valor;
    cellExcluir.innerHTML = `<button onclick="deleteFolha(this)">Excluir</button>`;

    saveFolha();
}

function saveFolha() {
    var tb = document.getElementById("tbFolha").getElementsByTagName('tbody')[0];
    var folha = [];
    for (var i = 0; i < tb.rows.length; i++) {
        var row = tb.rows[i];
        var funcionario = {
            nome: row.cells[0].innerText,
            cpf: row.cells[1].innerText,
            data: row.cells[2].innerText,
            valor: row.cells[3].innerText
        };
        folha.push(funcionario);
    }
    localStorage.setItem("folha", JSON.stringify(folha));
}

function loadFolha() {
    var folha = JSON.parse(localStorage.getItem("folha")) || [];
    var tb = document.getElementById("tbFolha").getElementsByTagName('tbody')[0];
    if (!tb) {
        console.error("Elemento tbody não encontrado");
        return;
    }
    for (var i = 0; i < folha.length; i++) {
        var funcionario = folha[i];
        var linha = tb.insertRow();

        var cellNome = linha.insertCell(0);
        var cellCpf = linha.insertCell(1);
        var cellData = linha.insertCell(2);
        var cellValor = linha.insertCell(3);
        var cellExcluir = linha.insertCell(4);

        cellNome.innerHTML = funcionario.nome;
        cellCpf.innerHTML = funcionario.cpf;
        cellData.innerHTML = funcionario.data;
        cellValor.innerHTML = funcionario.valor;
        cellExcluir.innerHTML = `<button onclick="deleteFolha(this)">Excluir</button>`;
    }
}

function updateFolha() {
    var nome = prompt("Digite o nome do funcionário a ser atualizado:");
    var folha = JSON.parse(localStorage.getItem("folha")) || [];
    var tb = document.getElementById("tbFolha").getElementsByTagName('tbody')[0];

    for (var i = 0; i < folha.length; i++) {
        if (folha[i].nome === nome) {
            folha[i].cpf = prompt("Atualize o CPF:", folha[i].cpf);
            folha[i].data = prompt("Atualize a data:", folha[i].data);
            folha[i].valor = prompt("Atualize o valor:", folha[i].valor);

            // Atualiza os dados na linha da tabela
            for (var j = 0; j < tb.rows.length; j++) {
                if (tb.rows[j].cells[0].innerText === nome) {
                    tb.rows[j].cells[1].innerText = folha[i].cpf;
                    tb.rows[j].cells[2].innerText = folha[i].data;
                    tb.rows[j].cells[3].innerText = folha[i].valor;
                }
            }
            break;
        }
    }
    localStorage.setItem("folha", JSON.stringify(folha));
    alert("Folha de pagamento atualizada com sucesso!");
}
 i
function deleteFolha(button) {
    var row = button.parentNode.parentNode;
    var nome = row.cells[0].innerText;
    if (confirma("Tem certeza que deseja excluir o registro de " + nome + "?")) {
        var folha = JSON.parse(localStorage.getItem("folha")) || [];
        folha = folha.filter(function(funcionario) {
            return funcionario.nome !== nome;
        });
        localStorage.setItem("folha", JSON.stringify(folha));
        row.parentNode.removeChild(row); 
        alert("Registro excluído com sucesso!");
    }
}
